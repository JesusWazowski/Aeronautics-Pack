#version 120
#extension GL_ARB_shader_texture_lod : enable
/* MakeUp - gbuffers_textured.fsh
Render: Particles

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define GBUFFER_TEXTURED

#include "/common/solid_blocks_fragment.glsl"
